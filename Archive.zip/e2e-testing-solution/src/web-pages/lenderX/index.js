const personalInformation = require('./personalInformation')

const lenderX = {
  personalInformation,
}

module.exports = lenderX
