const lenderX = require('./lenderX')

const webPages = {
  lenderX,
}

module.exports = webPages
