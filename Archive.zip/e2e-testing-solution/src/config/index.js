const constants = require('./constants')
const environment = require('./environment')

const config = {
  constants,
  environment,
}

module.exports = config
