const constants = {
  defaultWebActionTimeout: 5000,
}

module.exports = constants
