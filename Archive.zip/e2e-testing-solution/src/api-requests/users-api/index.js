const createLender = require('./createLender')

const usersApiRequests = {
  createLender,
}

module.exports = usersApiRequests
