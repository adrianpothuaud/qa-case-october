const sessionsApiRequests = {}

module.exports = sessionsApiRequests
